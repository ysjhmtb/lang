import UIKit

class ViewController: UIViewController {
    
    // MARK: BOOK Code -
    
    @IBOutlet var viewContainer:UIView!
    var isCenterAligned = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Define and attach the Tap Gesture on the root view
        let tapGesture = UITapGestureRecognizer(target: self, action: "tap:")
        view.addGestureRecognizer(tapGesture)
    }
    
    func tap(gesture:UITapGestureRecognizer){
        
        if gesture.state == .Ended {
            let touchLocation = gesture.locationInView(viewContainer)
            createView(touchLocation)
        }
    }
    
    @IBAction func updateAlignmentPref(segmentedControl:UISegmentedControl){
        isCenterAligned = segmentedControl.selectedSegmentIndex == 1
    }
    
    
    
    // MARK: Your code -
    
    func createView(location:CGPoint){
        
        // PUT YOUR CODE HERE -------------------------------
        

        
        // --------------------------------------------------
    }
    
    @IBAction func clear(){
        
        // PUT YOUR CODE HERE -------------------------------
        

        
        // --------------------------------------------------
    }
    
    
    
    // MARK: - Bonus code
    
    // This code creates a deep hierarchy inside the containerView.
    // Launch the application and press button Deep UI,
    // then from Xcode open Debug -> View Debugging -> Capture View Hierarchy
    // and rotate the view to inspect the hierarchy
    
    @IBAction func deepHierarchy(){
        
        clear()
        addInnerView(viewContainer)
    }
    
    // Add a UIView child to the received view and call itself on
    // the child view just added
    func addInnerView(parentView:UIView){
        
        // Create and attach the new view
        var viewSize = parentView.bounds.size
        viewSize.width -= 20
        viewSize.height -= 20
        let viewFrame = CGRect(origin: CGPoint(x: 10, y: 10), size:viewSize)
        let childView = UIView(frame: viewFrame)
        parentView.addSubview(childView)
        
        // Draw borders
        childView.layer.borderColor = UIColor.redColor().CGColor
        childView.layer.borderWidth = 1
        
        // Base case depending on width
        if viewSize.width > 40 {
            addInnerView(childView)
        }
    }
}

