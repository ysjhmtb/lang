import UIKit

class ViewController: UIViewController {

    var slider:ThermostatSlider?
    var handleColor:UIColor?
    
    @IBOutlet var label:UILabel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Setup the slider
    
        slider = ThermostatSlider(frame: CGRectMake(20, 20, 100, 100))
        slider?.translatesAutoresizingMaskIntoConstraints = false
        slider?.autoresizingMask = UIViewAutoresizing.None
        
        //ThermostatSlider.appearance().hotTrackColor = UIColor.greenColor()
        //ThermostatSlider.appearance().coldTrackColor = UIColor.redColor()
        
        view.addSubview(slider!)

        // Autolayout
        
        let cst_width = NSLayoutConstraint.constraintsWithVisualFormat("H:[slider(30)]",
            options: NSLayoutFormatOptions(),
            metrics: nil,
            views: ["slider":slider!])
        
        let cst_Y = NSLayoutConstraint.constraintsWithVisualFormat("V:|-150-[slider]-150-|",
            options: NSLayoutFormatOptions(),
            metrics: nil,
            views: ["slider":slider!])
        
        let cst_X = NSLayoutConstraint(
            item: slider!,
            attribute: NSLayoutAttribute.CenterX,
            relatedBy: NSLayoutRelation.Equal,
            toItem: view,
            attribute: NSLayoutAttribute.CenterX,
            multiplier: 1,
            constant: 0)
        
        view.addConstraints(cst_Y)
        view.addConstraint(cst_X)
        slider!.addConstraints(cst_width)
        
        slider!.addTarget(self, action: "updateLabel", forControlEvents: UIControlEvents.ValueChanged)
    }

    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)

    }
    
    func updateLabel(){
        self.label?.text = "\(slider!.value)"
    }

    @IBAction func resetSlider(){
        self.slider?.value = 0
    }
}

