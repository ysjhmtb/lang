import UIKit

class ThermostatSlider: UIControl {
    
    
    // MARK: Public vars
    
    var maxValue:Float = 1.0
    var value:Float {
        get { return _value}
        set (newValue){
            if newValue >= 0{
                _value = min(newValue, maxValue)
            }else{
                _value = max(newValue, -maxValue)
            }
            
            // Avoid animations
            CATransaction.begin()
            CATransaction.setAnimationDuration(0)
            updateHandle()
            updateTrack()
            CATransaction.commit()
            
            self.sendActionsForControlEvents(UIControlEvents.ValueChanged)
        }
    }
    
    dynamic var hotTrackColor = UIColor(red: 1.0, green: 0.4, blue: 0.4, alpha: 1.0)
    dynamic var coldTrackColor = UIColor(red: 0.4, green: 0.6, blue: 1.0, alpha: 1.0)

    
    // MARK: Private vars
    
    private var _value:Float = 0.0
    
    private var borderLayer = CALayer()
    private var trackLayer = CALayer()
    private var handleLayer = CALayer()
    
    
    // MARK: Initialization ---------------------------------------------------------------- **
    
    override init(frame:CGRect){
        
        super.init(frame:frame)
        
        // Init Layers frames
        designBorders()
        designTrack()
        designHandle()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder:aDecoder)
    }
    
    override func layoutSubviews() {
        
        super.layoutSubviews()
        
        // Update Layers frames
        updateBorder()
        updateHandle()
        updateTrack()
    }
    
    
    // MARK: Design ---------------------------------------------------------------------- **
    
    private func designBorders(){
        
        borderLayer.backgroundColor = UIColor.whiteColor().CGColor
        borderLayer.borderColor = UIColor(white: 0.9, alpha: 1.0).CGColor
        borderLayer.borderWidth = 1
        borderLayer.masksToBounds = true
        
        layer.addSublayer(borderLayer)
    }
    
    private func designHandle(){
        
        handleLayer.backgroundColor = UIColor.whiteColor().CGColor
        handleLayer.shadowColor = UIColor.blackColor().CGColor
        handleLayer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        handleLayer.shadowRadius = 2
        handleLayer.shadowOpacity = 0.3
        handleLayer.anchorPoint = CGPoint(x: 0.5, y: 0.5)

        self.layer.addSublayer(handleLayer)
    }
    
    private func designTrack(){
        
        trackLayer.anchorPoint = CGPoint(x: 0.5, y: 1)
        borderLayer.addSublayer(trackLayer)
    }
    
    
    // MARK: Update ---------------------------------------------------------------------- **
    
    // Update border frame and cornerRadius depending on the current controller bounds
    private func updateBorder(){
        
        borderLayer.frame = bounds
        borderLayer.cornerRadius = bounds.size.width / 2.0
    }
    
    // Update the handle position and other autolayout dependant parts 
    // depending on the current value
    private func updateHandle(){
        
        // Update size and radius depending on control width
        let controlWidth = bounds.size.width
        
        handleLayer.bounds.size = CGSize(
            width: controlWidth,
            height: controlWidth)
        handleLayer.cornerRadius = controlWidth / 2.0
        
        // Update handle position depending on value
        var position = borderLayer.position
        if value != 0 {
            position.y -= valueToY()
        }
        handleLayer.position = position
    }
    
    // Update track depending on the current value
    private func updateTrack(){
        
        // Define track size
        trackLayer.frame = CGRectMake(0, 0, self.bounds.width, 0)
        trackLayer.position = CGPoint(
            x: bounds.size.width/2,
            y: bounds.size.height/2)
        
        // Update layer height depending on value
        trackLayer.bounds.size.height = abs(valueToY())
        
        // Update anchor point and color depending on value
        if value >= 0{
            trackLayer.anchorPoint = CGPoint(x: 0.5, y: 1)
            trackLayer.backgroundColor = hotTrackColor.CGColor
        }else{
            trackLayer.anchorPoint = CGPoint(x: 0.5, y: 0)
            trackLayer.backgroundColor = coldTrackColor.CGColor
        }

    }
    
    // Convert the current value in Y relative coordinate
    private func valueToY()->CGFloat{
        return CGFloat(value) / CGFloat(maxValue) * (bounds.size.height - handleLayer.bounds.size.height / 2.0) / 2
    }
    
    // Set the value for the given Y absolute coordinate
    private func valueFromY(y:CGFloat)->Float{
        let cleanY = min(max(0, y), bounds.size.height)
        let trackHalfHeight = bounds.size.height / 2.0
        let translatedY = trackHalfHeight - cleanY
        
        return Float(translatedY) * maxValue / Float(trackHalfHeight)
    }
    
    
    // MARK: Touch Tracking ------------------------------------------------------------- **
    
    override func beginTrackingWithTouch(touch: UITouch, withEvent event: UIEvent?) -> Bool{
        
        self.handleLayer.transform = CATransform3DMakeScale(1.5, 1.5, 1)
        let point = touch.locationInView(self)
        value = valueFromY(point.y)
        self.highlighted = true
        
        for t in allTargets(){
            print(actionsForTarget(t, forControlEvent: UIControlEvents.ValueChanged))
        }
        return true
    }
    
    override func continueTrackingWithTouch(touch: UITouch, withEvent event: UIEvent?) -> Bool {
        let point = touch.locationInView(self)
        value = valueFromY(point.y)

        return true
    }
    
    override func endTrackingWithTouch(touch: UITouch?, withEvent event: UIEvent?) {
        self.handleLayer.transform = CATransform3DIdentity
        self.highlighted = false

    }
    
    override func cancelTrackingWithEvent(event: UIEvent?) {
        self.handleLayer.transform = CATransform3DIdentity
        self.highlighted = false
    }

}
