//: Playground - noun: a place where people can play

import UIKit
import XCPlayground

let containerView = UIView(frame: CGRect(x: 0.0, y: 0.0, width: 320.0, height: 640.0))
XCPlaygroundPage.currentPage.liveView = containerView
containerView.backgroundColor = UIColor.whiteColor()


// Border Layer

let sliderFrame = CGRect(x: 100, y: 30, width: 30, height: 300)

let borderLayer = CALayer()
borderLayer.frame = sliderFrame

borderLayer.backgroundColor = UIColor.whiteColor().CGColor
borderLayer.borderColor = UIColor(white: 0.9, alpha: 1.0).CGColor
borderLayer.borderWidth = 1
borderLayer.cornerRadius = sliderFrame.size.width / 2.0
borderLayer.masksToBounds = true

containerView.layer.addSublayer(borderLayer)

// Track Layer
let trackLayer = CALayer()
trackLayer.frame = CGRect(x: 0, y: 0, width: sliderFrame.size.width, height: 80)

trackLayer.anchorPoint = CGPoint(x: 0.5, y: 1)
trackLayer.backgroundColor = UIColor(red: 1.0, green: 0.4, blue: 0.4, alpha: 1.0).CGColor
trackLayer.position = CGPoint(
    x: borderLayer.bounds.size.width/2,
    y: borderLayer.bounds.size.height/2)

//borderLayer.addSublayer(trackLayer)

// Handle 
let handleLayer = CALayer()

handleLayer.position = borderLayer.position
handleLayer.position.y = 105
handleLayer.bounds.size = CGSize(
    width: borderLayer.bounds.size.width,
    height: borderLayer.bounds.size.width)
handleLayer.cornerRadius = borderLayer.bounds.size.width / 2.0

handleLayer.backgroundColor = UIColor.whiteColor().CGColor
handleLayer.shadowColor = UIColor.blackColor().CGColor
handleLayer.shadowOffset = CGSize(width: 0.0, height: 0.0)
handleLayer.shadowRadius = 2
handleLayer.shadowOpacity = 0.3
handleLayer.anchorPoint = CGPoint(x: 0.5, y: 0.5)

containerView.layer.addSublayer(handleLayer)
