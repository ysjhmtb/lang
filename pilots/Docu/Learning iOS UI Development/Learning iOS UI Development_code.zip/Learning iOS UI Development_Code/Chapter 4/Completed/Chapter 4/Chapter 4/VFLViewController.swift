//
//  VFLViewController.swift
//  Chapter 4
//
//  Created by Yari D'areglia on 03/07/15.
//  Copyright (c) 2015 Packtpub. All rights reserved.
//

import UIKit

class VFLViewController: UIViewController {

    let redView = UIView()
    let greenView = UIView()
    var viewsDictionary: [String:AnyObject]{
        get {
            return ["redView":self.redView, "greenView":self.greenView]
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        redView.translatesAutoresizingMaskIntoConstraints = false
        redView.backgroundColor = UIColor(red: 0.95, green: 0.2, blue: 0.0, alpha: 1.0)
        
        greenView.translatesAutoresizingMaskIntoConstraints = false
        greenView.backgroundColor = UIColor(red: 0.5, green: 0.80, blue: 0.5, alpha: 1.0)
        
        view.addSubview(redView)
        view.addSubview(greenView)
        
        setupRedView()
        setupGreenView()
        //setupGreenView_Relation()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setupRedView(){
        
        // Set Size
        let cst_height = NSLayoutConstraint.constraintsWithVisualFormat(
                                "V:[redView(100)]",
                                options: NSLayoutFormatOptions(),
                                metrics: nil,
                                views: viewsDictionary)
        let cst_width = NSLayoutConstraint.constraintsWithVisualFormat(
                                "H:[redView(100)]",
                                options: NSLayoutFormatOptions(),
                                metrics: nil,
                                views: viewsDictionary)
        
        // Set Position
        let cst_Y = NSLayoutConstraint.constraintsWithVisualFormat(
                                "V:|-30-[redView]",
                                options: NSLayoutFormatOptions(),
                                metrics: nil,
                                views: viewsDictionary)
        let cst_X = NSLayoutConstraint.constraintsWithVisualFormat(
                                "H:|-30-[redView]",
                                options: NSLayoutFormatOptions(),
                                metrics: nil,
                                views: viewsDictionary)
        
        // Attach Constraints
        self.redView.addConstraints(cst_height)
        self.redView.addConstraints(cst_width)
        
        self.view.addConstraints(cst_Y)
        self.view.addConstraints(cst_X)

    }
    
    func setupGreenView(){
        
        // Set Size
        let cst_height = NSLayoutConstraint.constraintsWithVisualFormat(
            "V:[greenView(100)]",
            options: NSLayoutFormatOptions(),
            metrics: nil,
            views: viewsDictionary)
        let cst_width = NSLayoutConstraint.constraintsWithVisualFormat(
            "H:[greenView(100)]",
            options: NSLayoutFormatOptions(),
            metrics: nil,
            views: viewsDictionary)
        
        // Set Position
        let cst_Y = NSLayoutConstraint.constraintsWithVisualFormat(
            "V:[redView]-10-[greenView]",
            options: NSLayoutFormatOptions(),
            metrics: nil,
            views: viewsDictionary)
        let cst_X = NSLayoutConstraint.constraintsWithVisualFormat(
            "H:[redView]-10-[greenView]",
            options: NSLayoutFormatOptions(),
            metrics: nil,
            views: viewsDictionary)
        
        // Attach Constraints
        self.greenView.addConstraints(cst_height)
        self.greenView.addConstraints(cst_width)
        
        self.view.addConstraints(cst_Y)
        self.view.addConstraints(cst_X)
    }
    
    func setupGreenView_Relation(){
        
        // Set Size
        let cst_height = NSLayoutConstraint(
            item: greenView,
            attribute: NSLayoutAttribute.Height,
            relatedBy: NSLayoutRelation.Equal,
            toItem: redView,
            attribute: NSLayoutAttribute.Height,
            multiplier: 0.5,
            constant: 10.0)
        
        let cst_width = NSLayoutConstraint.constraintsWithVisualFormat(
            "H:[greenView(100)]",
            options: NSLayoutFormatOptions(),
            metrics: nil,
            views: viewsDictionary)
        
        // Set Position
        let cst_Y = NSLayoutConstraint.constraintsWithVisualFormat(
            "V:[redView]-10-[greenView]",
            options: NSLayoutFormatOptions(),
            metrics: nil,
            views: viewsDictionary)
        let cst_X = NSLayoutConstraint.constraintsWithVisualFormat(
            "H:[redView]-10-[greenView]",
            options: NSLayoutFormatOptions(),
            metrics: nil,
            views: viewsDictionary)
        
        // Attach Constraints
        self.view.addConstraint(cst_height)
        self.greenView.addConstraints(cst_width)
        
        self.view.addConstraints(cst_Y)
        self.view.addConstraints(cst_X)
    }

}
