import UIKit

class ViewController: UIViewController {

    let roundedLayer = CALayer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Layer setup
        roundedLayer.backgroundColor = UIColor(red: 0.8, green: 0.0, blue: 0.0, alpha: 1.0).CGColor
        roundedLayer.cornerRadius = 20
        roundedLayer.bounds = CGRect(x: 0, y: 0, width: 100, height: 100)
        roundedLayer.position = CGPoint(x: 60, y: 100)
        view.layer.addSublayer(roundedLayer)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    @IBAction func animateLayer(){
        
        // BASIC ANIMATION
        // YOUR CODE HERE ------------------
        
        //----------------------------------

    }
    
    
    // MARK: Animations 
    
    func positionAnimation(){
    
        // YOUR CODE HERE ------------------
        
        //----------------------------------
    }
    
    func groupAnimation(){
        
        // YOUR CODE HERE ------------------
        
        //----------------------------------
    }
    
    func keyframeAnimation(){
        
        // YOUR CODE HERE ------------------
        
        //----------------------------------
    }

}

