import UIKit

class ViewController: UIViewController {

    let roundedLayer = CALayer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Layer setup
        roundedLayer.backgroundColor = UIColor(red: 0.8, green: 0.0, blue: 0.0, alpha: 1.0).CGColor
        roundedLayer.cornerRadius = 20
        roundedLayer.bounds = CGRect(x: 0, y: 0, width: 100, height: 100)
        roundedLayer.position = CGPoint(x: 60, y: 100)
        view.layer.addSublayer(roundedLayer)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    @IBAction func animateLayer(){
        
        // BASIC ANIMATION
        // YOUR CODE HERE ------------------
        
        //positionAnimation()
        
        //groupAnimation()
        
        keyframeAnimation()
        
        //----------------------------------

    }
    
    
    // MARK: Animations 
    
    func positionAnimation(){
        
        // Position animation
        let animation = CABasicAnimation(keyPath: "position.x")
        animation.fromValue = 60
        animation.toValue = 200
        animation.duration = 0.5
        animation.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
        animation.fillMode = kCAFillModeForwards
        animation.removedOnCompletion = false
        animation.repeatCount = 3
        animation.autoreverses = true
        
        roundedLayer.addAnimation(animation, forKey: "Move")
    }
    
    func groupAnimation(){
        
        // Opacity
        let opacityAnimation = CABasicAnimation(keyPath: "opacity")
        opacityAnimation.fromValue = 1
        opacityAnimation.toValue = 0
        
        // Scale
        let scaleAnimation = CABasicAnimation(keyPath: "transform")
        let scale = CATransform3DMakeScale(0.5, 0.5, 1.0)
        scaleAnimation.fromValue = NSValue(CATransform3D: CATransform3DIdentity)
        scaleAnimation.toValue = NSValue(CATransform3D: scale)
        
        //Group
        let group = CAAnimationGroup()
        group.animations = [opacityAnimation, scaleAnimation]
        group.duration = 1.0
        group.repeatCount = 2
        group.autoreverses = true
        
        roundedLayer.addAnimation(group, forKey: "HeartBeat")
    }
    
    func keyframeAnimation(){
        
        // keyframe animation
        let animation = CAKeyframeAnimation(keyPath: "backgroundColor")
        animation.values = [roundedLayer.backgroundColor!,
                            UIColor.greenColor().CGColor,
                            UIColor.blueColor().CGColor,
                            UIColor.yellowColor().CGColor]
        animation.fillMode = kCAFillModeForwards
        animation.removedOnCompletion = false
        
        // Define the Keyframes
        animation.keyTimes = [0, 0.2, 0.8, 1]
        animation.duration = 10
        
        // Attach the animation
        roundedLayer.addAnimation(animation, forKey: "Colors")

    }
    
    
    @IBAction func removeColorsAnimation(){
    
        roundedLayer.backgroundColor = roundedLayer.presentationLayer()?.backgroundColor
        roundedLayer.removeAnimationForKey("Colors")
    }

    func fadeInFadeOut(){
        UIView.animateWithDuration(5, animations: { () -> Void in
            
        }) { (completed) -> Void in
            UIView.animateWithDuration(2){
                () -> Void in
                self.view.alpha = 0
            }
        }
    }

}

