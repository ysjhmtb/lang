import UIKit
class UIHelpersView: UIView {

    override func drawRect(rect: CGRect) {
        drawRedRect()
        //drawBlendedRects()
        //cgToBezierRect()
    }

    func drawRedRect(){
        let rect = CGRectMake(10, 10, 80, 80)
        UIColor.redColor().setFill()
        UIColor.blackColor().setStroke()
        UIRectFill(rect)
        UIRectFrame(rect)
    }
    
    func drawBlendedRects(){
        let rect_A = CGRectMake(10, 10, 80, 80)
        UIColor.greenColor().setFill()
        UIRectFill(rect_A)
        
        let rect_B = CGRectMake(30, 30, 80, 80)
        UIColor.redColor().setFill()
        UIRectFillUsingBlendMode(rect_B, CGBlendMode.Multiply)
    }
    
    func drawBezierRect(){
        let rect = CGRectMake(10, 10, 80, 80)
        let path = UIBezierPath(rect: rect)
        
        UIColor.blueColor().setStroke()
        path.lineWidth = 5
        path.stroke()
    }
    
    func drawBezierCircle(){
        let rect = CGRectMake(10, 10, 80, 80)
        let path = UIBezierPath(ovalInRect: rect)
        
        UIColor.blueColor().setStroke()
        path.lineWidth = 5
        path.stroke()
    }
    
    func cgToBezierRect(){
        let rect = CGRectMake(10, 10, 80, 80)
        let cgPath = CGPathCreateMutable()
        CGPathAddEllipseInRect(cgPath, nil, rect)
        
        let bezierPath = UIBezierPath()
        bezierPath.CGPath = cgPath
        
        UIColor.greenColor().setStroke()
        bezierPath.lineWidth = 5
        bezierPath.stroke()
    }
}
