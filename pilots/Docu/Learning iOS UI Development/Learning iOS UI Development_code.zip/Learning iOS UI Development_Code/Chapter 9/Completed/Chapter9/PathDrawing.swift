import UIKit

class PathDrawing: UIView {

    override func drawRect(rect: CGRect) {
        
        // Build the Path
        //let path = simpleRectPath()
        //let path = simpleMutableRectPath()
        //let path = simpleLine()
        //let path = multiLine()
        let path = simpleCurve()
        
        // Draw the path
        let context = UIGraphicsGetCurrentContext()
        UIColor.redColor().set()
        
        CGContextAddPath(context, path)
        CGContextDrawPath(context, CGPathDrawingMode.Stroke)
        
        //drawPath(context)
    }
    
    // MARK:  Path composing
    
    func simpleRectPath()->CGPath {
        let rect = CGRect(x: 30, y: 30, width: 80, height: 80)
        let path = CGPathCreateWithRect(rect, nil)
        
        return path
    }
    
    func simpleMutableRectPath()->CGMutablePath {
        let rect = CGRect(x: 30, y: 30, width: 80, height: 80)
        let path = CGPathCreateMutable()
        CGPathAddRect(path, nil, rect)
        
        return path
    }
    
    func simpleLine()->CGMutablePath{
        
        let path = CGPathCreateMutable()
        CGPathMoveToPoint(path, nil, 20, 20)
        CGPathAddLineToPoint(path, nil, 100, 100)
        
        return path
    }
    
    func multiLine()->CGMutablePath{
        let path = CGPathCreateMutable()
        
        CGPathMoveToPoint(path, nil, 20, 20)
        
        CGPathAddLineToPoint(path, nil, 100, 100)
        CGPathAddLineToPoint(path, nil, 200, 50)
        
        CGPathCloseSubpath(path)
        
        return path
    }
    
    func simpleCurve()->CGMutablePath{
        
        let path = CGPathCreateMutable()
        CGPathMoveToPoint(path, nil, 20, 20)
        CGPathAddQuadCurveToPoint(path, nil, 100, 20, 100, 100)
        
        return path
    }
    
    
    // MARK: Path Drawing 
    
    func drawPath(context:CGContext?){
        let rect = CGRect(x: 30, y: 30, width: 80, height: 80)
        let path = CGPathCreateWithRect(rect, nil)
        
        UIColor.grayColor().setFill()
        UIColor.redColor().setStroke()
        
        CGContextSetLineWidth(context, 2.0)
        CGContextSetLineCap(context, CGLineCap.Round)
        
        CGContextAddPath(context, path)
        CGContextDrawPath(context, CGPathDrawingMode.FillStroke)
        //CGContextStrokePath(context)
        //CGContextFillPath(context)
    }
    
}
