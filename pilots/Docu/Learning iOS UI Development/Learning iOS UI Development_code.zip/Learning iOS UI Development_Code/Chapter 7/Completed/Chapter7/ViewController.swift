import UIKit

class ViewController: UIViewController {

    var redView: UIView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Initialize the redview
        redView = UIView(frame: CGRectMake(0, 0, 100, 100))
        redView?.backgroundColor = UIColor.redColor()
        redView?.center = view.center
        view.addSubview(redView!)
        
        // Initialize and attach the gesture
        let pinchGR = UIPinchGestureRecognizer(target: self, action: "pinch:")
        view.addGestureRecognizer(pinchGR)
    }

    func pinch(gesture:UIPinchGestureRecognizer){
        
        // Handle different gesture states
        switch gesture.state {
            
            case .Began:
                redView?.layer.transform = CATransform3DIdentity
            
            case .Changed:
                //Apply transform
                let transform = CATransform3DMakeScale(gesture.scale, gesture.scale, 0)
                redView?.layer.transform = transform
            
            default:
                // Reset the original position
                UIView.animateWithDuration(0.2, animations: { () -> Void in
                    self.redView?.layer.transform = CATransform3DIdentity
                })
        }
    }
}

