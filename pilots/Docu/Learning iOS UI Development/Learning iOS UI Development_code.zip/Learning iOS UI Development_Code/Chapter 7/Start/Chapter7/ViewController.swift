import UIKit

class ViewController: UIViewController {

    var redView: UIView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Initialize the redview
        redView = UIView(frame: CGRectMake(0, 0, 100, 100))
        redView?.backgroundColor = UIColor.redColor()
        redView?.center = view.center
        view.addSubview(redView!)
        
        // YOUR CODE HERE ------
        
        // ---------------------
    }

    func pinch(gesture:UIPinchGestureRecognizer){
        
        // YOUR CODE HERE ------
        
        // ---------------------
        
    }
}

