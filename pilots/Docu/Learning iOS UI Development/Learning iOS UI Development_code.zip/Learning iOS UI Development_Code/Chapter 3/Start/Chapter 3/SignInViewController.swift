//
//  SignInViewController.swift
//  Chapter 3
//
//  Created by Yari D'areglia on 21/06/15.
//  Copyright (c) 2015 Packtpub. All rights reserved.
//

import UIKit

class SignInViewController: UIViewController {
    
    @IBOutlet weak var usernameTextField:UITextField!
    @IBOutlet weak var passwordTextField:UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // YOUR CODE HERE ----------------------------------------------------
    override func shouldPerformSegueWithIdentifier(
        identifier: String,
        sender: AnyObject?) -> Bool {
            
        
        return true
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue,
                                 sender: AnyObject?) {

    }
    // EOF YOUR CODE HERE ----------------------------------------------------

}
