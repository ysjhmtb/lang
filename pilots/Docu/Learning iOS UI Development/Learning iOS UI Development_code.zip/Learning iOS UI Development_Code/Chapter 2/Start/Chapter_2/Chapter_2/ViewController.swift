import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        customizeSlider()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    func customizeSlider(){
        
        // YOUR CODE HERE -------------------------------
        // Initialize the images
        
        // YOUR CODE HERE -------------------------------
    }

}

